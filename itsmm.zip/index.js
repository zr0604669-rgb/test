const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, jidNormalizedUser } = require('@whiskeysockets/baileys');
const pino = require('pino');
const readline = require('readline');

// ==========================================
// 1. CONFIGURATION & CONSTANTS
// ==========================================
// Add your specific admin numbers here using the standard phone number format.
const ADMINS = [
    '923xxxxxxxxx@s.whatsapp.net', 
    '923xxxxxxxxy@s.whatsapp.net',
    '923444327310@s.whatsapp.net'
];

// Custom text strings mapped to command numbers
const { bug1 } = require('./msg/bug1.js');
const { bug2 } = require('./msg/bug2.js');
const { bug3 } = require('./msg/bug3.js');
const { bug4 } = require('./msg/bug4.js');
const { bug5 } = require('./msg/bug5.js');
const { bug6 } = require('./msg/bug6.js');
const { bug7 } = require('./msg/bug7.js');
require('./msg/bug8.js');
const { ios } = require('./msg/ios.js');
const TEXT_CONSTANTS = {
    '1': bug1,
    '2': bug2,
    '3': bug3,
    '4': bug4,
    '5': bug5,
    '6': bug6,
    '7': bug7,
    '8': bug8,
    '9': ios
};

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

// Helper function to create sequential execution delays
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: false, 
        logger: pino({ level: 'silent' }), 
        browser: ['Ubuntu', 'Chrome', '111.0'] 
    });

    // ==========================================
    // 2. PAIRING CODE LOGIC
    // ==========================================
    if (!sock.authState.creds.registered) {
        setTimeout(async () => {
            console.log('\n--- WhatsApp Pairing ---');
            const phoneNumber = await question('Enter your phone number with the country code (e.g., 12345678900): ');
            const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
            
            try {
                const code = await sock.requestPairingCode(cleanNumber);
                const formattedCode = code?.match(/.{1,4}/g)?.join('-') || code;
                console.log(`\n> Your pairing code is: \x1b[32m${formattedCode}\x1b[0m`);
            } catch (err) {
                console.error('Failed to request pairing code. Ensure your number is correct.', err);
            }
        }, 2000);
    }

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== 401;
            console.log(`Connection closed. Reconnecting: ${shouldReconnect}`);
            if (shouldReconnect) startBot(); 
        } else if (connection === 'open') {
            console.log('\n✅ Successfully connected to WhatsApp!');
        }
    });

    // ==========================================
    // 3. MESSAGE & COMMAND LOGIC
    // ==========================================
    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0];
        if (!msg.message) return; 

        const chatId = jidNormalizedUser(msg.key.remoteJid);
        const rawSenderId = jidNormalizedUser(msg.key.participant || msg.key.remoteJid);
        const isFromMe = msg.key.fromMe;

        // LID Resolution Workaround
        let resolvedSenderId = rawSenderId;
        if (rawSenderId.endsWith('@lid')) {
            try {
                const mappedPn = await sock.signalRepository.lidMapping.getPNForLID(rawSenderId);
                if (mappedPn) {
                    resolvedSenderId = jidNormalizedUser(mappedPn);
                }
            } catch (error) {
                // Fail silently and use fallback LID
            }
        }

        const isAuthorized = isFromMe || ADMINS.includes(resolvedSenderId);

        // Safely extract text input
        const messageType = Object.keys(msg.message)[0];
        let text = '';
        if (messageType === 'conversation') {
            text = msg.message.conversation;
        } else if (messageType === 'extendedTextMessage') {
            text = msg.message.extendedTextMessage.text;
        }

        if (!text) return;

        // --- COMMAND: ./id ---
        if (text === './id') {
            if (!isAuthorized) return;
            
            const isGroup = chatId.endsWith('@g.us');
            let chatName = 'Unknown Chat';
            try {
                if (isGroup) {
                    const groupMetadata = await sock.groupMetadata(chatId);
                    chatName = groupMetadata.subject;
                } else {
                    chatName = msg.pushName || 'Private Chat';
                }
                const replyMessage = `*Chat Name:* ${chatName}\n*Chat ID:* ${chatId}`;
                await sock.sendMessage(chatId, { text: replyMessage }, { quoted: msg });
            } catch (error) {
                console.error('Error executing ./id command:', error);
            }
            return;
        }

        // --- SHORT CODE COMMANDS: ./1 to ./9 ---
        // Expected format: ./1 [amount] [target_id]
        if (text.startsWith('./')) {
            if (!isAuthorized) return;

            // Split the incoming command string by spaces
            const args = text.split(/\s+/);
            const commandKey = args[0].replace('./', ''); // Extracts the index (e.g., "1")

            // Verify if the requested index exists within our constants
            if (TEXT_CONSTANTS.hasOwnProperty(commandKey)) {
                let amount = parseInt(args[1], 10) || 1;
                let targetJid = args[2];

                // Fallback to current chat environment if no third-party JID is defined
                if (!targetJid) {
                    targetJid = chatId;
                } else {
                    targetJid = jidNormalizedUser(targetJid);
                }

                // Enforce safety limits to protect group experiences
                if (amount > 10) {
                    amount = 10; 
                }
                if (amount < 1) {
                    amount = 1;
                }

                const payloadText = TEXT_CONSTANTS[commandKey];
                console.log(`Executing numeric macro [${commandKey}] x${amount} target: ${targetJid}`);

                // Execute controlled loop with strict scheduling rules
                for (let i = 0; i < amount; i++) {
                    try {
                        await sock.sendMessage(targetJid, { text: payloadText });
                        
                        // Apply safety delay between subsequent iterations
                        if (i < amount - 1) {
                            await delay(1000); 
                        }
                    } catch (error) {
                        console.error(`Failed to send message during step ${i}:`, error);
                        break;
                    }
                }
            }
        }
    });
}

startBot();
